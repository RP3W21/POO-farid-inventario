﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.IO;
using static iventariov1.Form1;

namespace iventariov1
{
    public partial class Form3 : Form
    {
        public Form3()
        {
            InitializeComponent();
            loadnombre.Text = DatosUsuario.NombreUsuario;
            this.Load += new EventHandler(FormProductos_Load);
        }

        private void label3_Click(object sender, EventArgs e)
        {

        }

        private void linkLabel1_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {
            Form1 iniciarform = new Form1();
            iniciarform.Show();
            this.Hide();
        }

        private void label1_Click(object sender, EventArgs e)
        {
            loadnombre.Text = "Bienvenido, " + DatosUsuario.NombreUsuario + "!";
        }

        private void checkedListBox1_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        private void pictureBox2_Click(object sender, EventArgs e)
        {

        }

        private void label4_Click(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {

        }
        private void FormProductos_Load(object sender, EventArgs e)
        {
            // Leer todas las líneas del archivo
            string[] lineas = File.ReadAllLines("Productos.txt");

            // Recorrer las líneas del archivo
            foreach (string linea in lineas)
            {
                // Buscar la línea que comienza con "Producto: "
                if (linea.StartsWith("Producto: "))
                {
                    // Extraer el nombre del producto, precio y cantidad
                    string[] partes = linea.Split(',');
                    string nombreProducto = partes[0].Split(':')[1].Trim();
                    string precio = partes[1].Split(':')[1].Trim();
                    string cantidad = partes[2].Split(':')[1].Trim();

                    // Agregar el producto al checkedListBox1
                    checkedListBox1.Items.Add($"{nombreProducto} - ${precio} - Cantidad: {cantidad}");
                }
            }
            // Leer todas las líneas del archivo
            string[] lineasCarrito = File.ReadAllLines("carrito.txt");

            // Recorrer las líneas del archivo
            foreach (string linea in lineasCarrito)
            {
                // Buscar la línea que comienza con el nombre de usuario
                if (linea.StartsWith(DatosUsuario.NombreUsuario + " - "))
                {
                    // Extraer el producto y cantidad
                    string producto = linea.Substring(DatosUsuario.NombreUsuario.Length + 3);
                    string[] partes = producto.Split(' ');
                    string nombreProducto = partes[0];
                    string cantidad = partes[2];

                    // Agregar el producto al listBox1
                    listBox1.Items.Add(nombreProducto + " x " + cantidad);
                }
            }
        }

        private void button2_Click(object sender, EventArgs e)
        {
            // Obtener los productos seleccionados
            foreach (string producto in checkedListBox1.CheckedItems)
            {
                // Agregar el producto al carrito
                AgregarAlCarrito(producto);
            }
        }
        private void AgregarAlCarrito(string producto)
        {
            // Obtener la cantidad del producto
            int cantidad = int.Parse(textBox1.Text);

            // Actualizar la cantidad del producto en el archivo
            ActualizarCantidadProducto(producto, cantidad);

            // Agregar el producto al carrito
            listBox1.Items.Add(producto + " x " + cantidad);

            // Escribir el producto en el archivo carrito.txt
            string linea = $"{DatosUsuario.NombreUsuario} - {producto} x {cantidad}";
            File.AppendAllText("carrito.txt", linea + Environment.NewLine);
        }
        private void ActualizarCantidadProducto(string producto, int cantidad)
        {
            // Leer todas las líneas del archivo
            string[] lineas = File.ReadAllLines("Productos.txt");

            // Recorrer las líneas del archivo
            for (int i = 0; i < lineas.Length; i++)
            {
                // Buscar la línea que comienza con "Product: " y contiene el producto
                if (lineas[i].StartsWith("Producto: " + producto))
                {
                    // Extraer la cantidad actual del producto
                    int cantidadActual = int.Parse(lineas[i].Split(',')[2].Trim().Split(':')[1]);

                    // Actualizar la cantidad del producto
                    cantidadActual -= cantidad;

                    // Actualizar la línea con la nueva cantidad
                    string[] partes = lineas[i].Split(',');
                    partes[2] = "Cantidad: " + cantidadActual;
                    string lineaActualizada = string.Join(",", partes);

                    // Reemplazar la línea original con la línea actualizada
                    lineas[i] = lineaActualizada;

                    // Escribir la línea actualizada en el archivo
                    File.WriteAllLines("Productos.txt", lineas);
                    break;
                }
            }
        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {

        }

        private void listBox2_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        private void listBox1_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        private void checkedListBox1_SelectedIndexChanged_1(object sender, EventArgs e)
        {

        }
    }
}
