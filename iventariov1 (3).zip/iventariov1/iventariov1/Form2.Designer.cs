﻿namespace iventariov1
{
    partial class Form2
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Form2));
            panel1 = new Panel();
            label5 = new Label();
            label4 = new Label();
            label3 = new Label();
            ir_inicio = new LinkLabel();
            label2 = new Label();
            pictureBox4 = new PictureBox();
            Con_contraseña = new TextBox();
            pictureBox3 = new PictureBox();
            pictureBox2 = new PictureBox();
            pictureBox1 = new PictureBox();
            button2 = new Button();
            Registrar_contraseña = new TextBox();
            Registra_usuario = new TextBox();
            label1 = new Label();
            panel1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)pictureBox4).BeginInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox3).BeginInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox2).BeginInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox1).BeginInit();
            SuspendLayout();
            // 
            // panel1
            // 
            panel1.BackColor = Color.White;
            panel1.BorderStyle = BorderStyle.Fixed3D;
            panel1.Controls.Add(label5);
            panel1.Controls.Add(label4);
            panel1.Controls.Add(label3);
            panel1.Controls.Add(ir_inicio);
            panel1.Controls.Add(label2);
            panel1.Controls.Add(pictureBox4);
            panel1.Controls.Add(Con_contraseña);
            panel1.Controls.Add(pictureBox3);
            panel1.Controls.Add(pictureBox2);
            panel1.Controls.Add(pictureBox1);
            panel1.Controls.Add(button2);
            panel1.Controls.Add(Registrar_contraseña);
            panel1.Controls.Add(Registra_usuario);
            panel1.Controls.Add(label1);
            panel1.Location = new Point(12, 30);
            panel1.Name = "panel1";
            panel1.Size = new Size(700, 331);
            panel1.TabIndex = 2;
            panel1.Paint += panel1_Paint;
            // 
            // label5
            // 
            label5.AutoSize = true;
            label5.Font = new Font("MS PGothic", 11.25F, FontStyle.Regular, GraphicsUnit.Point);
            label5.ForeColor = Color.Black;
            label5.Location = new Point(53, 184);
            label5.Name = "label5";
            label5.Size = new Size(147, 15);
            label5.TabIndex = 15;
            label5.Text = "Confirmar Contraseña";
            // 
            // label4
            // 
            label4.AutoSize = true;
            label4.Font = new Font("MS PGothic", 11.25F, FontStyle.Regular, GraphicsUnit.Point);
            label4.ForeColor = Color.Black;
            label4.Location = new Point(53, 137);
            label4.Name = "label4";
            label4.Size = new Size(80, 15);
            label4.TabIndex = 14;
            label4.Text = "Contraseña";
            // 
            // label3
            // 
            label3.AutoSize = true;
            label3.Font = new Font("MS PGothic", 11.25F, FontStyle.Regular, GraphicsUnit.Point);
            label3.ForeColor = Color.Black;
            label3.Location = new Point(54, 73);
            label3.Name = "label3";
            label3.Size = new Size(56, 15);
            label3.TabIndex = 13;
            label3.Text = "Nombre";
            label3.Click += label3_Click;
            // 
            // ir_inicio
            // 
            ir_inicio.AutoSize = true;
            ir_inicio.Font = new Font("MS PGothic", 11.25F, FontStyle.Regular, GraphicsUnit.Point);
            ir_inicio.LinkColor = Color.Blue;
            ir_inicio.Location = new Point(193, 302);
            ir_inicio.Name = "ir_inicio";
            ir_inicio.Size = new Size(115, 15);
            ir_inicio.TabIndex = 12;
            ir_inicio.TabStop = true;
            ir_inicio.Text = "inicia sesion aqui";
            ir_inicio.LinkClicked += ir_inicio_LinkClicked_1;
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.Font = new Font("MS PGothic", 11.25F, FontStyle.Regular, GraphicsUnit.Point);
            label2.ForeColor = Color.Black;
            label2.Location = new Point(53, 302);
            label2.Name = "label2";
            label2.Size = new Size(134, 15);
            label2.TabIndex = 11;
            label2.Text = "ya estas registrado?";
            label2.Click += label2_Click;
            // 
            // pictureBox4
            // 
            pictureBox4.Image = Properties.Resources.candado;
            pictureBox4.Location = new Point(18, 202);
            pictureBox4.Name = "pictureBox4";
            pictureBox4.Size = new Size(29, 26);
            pictureBox4.SizeMode = PictureBoxSizeMode.StretchImage;
            pictureBox4.TabIndex = 10;
            pictureBox4.TabStop = false;
            // 
            // Con_contraseña
            // 
            Con_contraseña.Font = new Font("MS PGothic", 14.25F, FontStyle.Regular, GraphicsUnit.Point);
            Con_contraseña.Location = new Point(53, 202);
            Con_contraseña.Name = "Con_contraseña";
            Con_contraseña.PasswordChar = '*';
            Con_contraseña.Size = new Size(290, 26);
            Con_contraseña.TabIndex = 9;
            Con_contraseña.TextChanged += textBox3_TextChanged;
            // 
            // pictureBox3
            // 
            pictureBox3.Image = Properties.Resources.minicionousuario;
            pictureBox3.Location = new Point(19, 91);
            pictureBox3.Name = "pictureBox3";
            pictureBox3.Size = new Size(29, 26);
            pictureBox3.SizeMode = PictureBoxSizeMode.StretchImage;
            pictureBox3.TabIndex = 8;
            pictureBox3.TabStop = false;
            pictureBox3.Click += pictureBox3_Click;
            // 
            // pictureBox2
            // 
            pictureBox2.Image = Properties.Resources.candado;
            pictureBox2.Location = new Point(18, 155);
            pictureBox2.Name = "pictureBox2";
            pictureBox2.Size = new Size(29, 26);
            pictureBox2.SizeMode = PictureBoxSizeMode.StretchImage;
            pictureBox2.TabIndex = 7;
            pictureBox2.TabStop = false;
            pictureBox2.Click += pictureBox2_Click;
            // 
            // pictureBox1
            // 
            pictureBox1.Image = (Image)resources.GetObject("pictureBox1.Image");
            pictureBox1.Location = new Point(350, 77);
            pictureBox1.Name = "pictureBox1";
            pictureBox1.Size = new Size(168, 151);
            pictureBox1.SizeMode = PictureBoxSizeMode.StretchImage;
            pictureBox1.TabIndex = 6;
            pictureBox1.TabStop = false;
            // 
            // button2
            // 
            button2.BackColor = Color.FromArgb(67, 90, 217);
            button2.FlatStyle = FlatStyle.Flat;
            button2.Font = new Font("MS PGothic", 15.75F, FontStyle.Bold, GraphicsUnit.Point);
            button2.ForeColor = SystemColors.ButtonFace;
            button2.Location = new Point(53, 261);
            button2.Name = "button2";
            button2.Size = new Size(187, 38);
            button2.TabIndex = 3;
            button2.Text = "Registrar";
            button2.UseVisualStyleBackColor = false;
            button2.Click += button2_Click;
            // 
            // Registrar_contraseña
            // 
            Registrar_contraseña.Font = new Font("MS PGothic", 14.25F, FontStyle.Regular, GraphicsUnit.Point);
            Registrar_contraseña.Location = new Point(53, 155);
            Registrar_contraseña.Name = "Registrar_contraseña";
            Registrar_contraseña.PasswordChar = '*';
            Registrar_contraseña.Size = new Size(290, 26);
            Registrar_contraseña.TabIndex = 2;
            Registrar_contraseña.TextChanged += textBox2_TextChanged;
            // 
            // Registra_usuario
            // 
            Registra_usuario.Font = new Font("MS PGothic", 14.25F, FontStyle.Regular, GraphicsUnit.Point);
            Registra_usuario.Location = new Point(54, 91);
            Registra_usuario.Name = "Registra_usuario";
            Registra_usuario.Size = new Size(289, 26);
            Registra_usuario.TabIndex = 1;
            Registra_usuario.TextChanged += textBox1_TextChanged;
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Font = new Font("MS PGothic", 26.25F, FontStyle.Bold, GraphicsUnit.Point);
            label1.ForeColor = Color.FromArgb(22, 22, 22);
            label1.Location = new Point(28, 21);
            label1.Name = "label1";
            label1.Size = new Size(281, 35);
            label1.TabIndex = 0;
            label1.Text = "Registrar usuario";
            // 
            // Form2
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            BackColor = Color.FromArgb(67, 90, 217);
            ClientSize = new Size(724, 373);
            Controls.Add(panel1);
            ForeColor = Color.FromArgb(67, 90, 217);
            FormBorderStyle = FormBorderStyle.FixedSingle;
            Name = "Form2";
            StartPosition = FormStartPosition.CenterScreen;
            Text = "Form2";
            Load += Form2_Load;
            panel1.ResumeLayout(false);
            panel1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)pictureBox4).EndInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox3).EndInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox2).EndInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox1).EndInit();
            ResumeLayout(false);
        }

        #endregion

        private Panel panel1;
        private PictureBox pictureBox3;
        private PictureBox pictureBox2;
        private Button button2;
        private TextBox Registrar_contraseña;
        private TextBox Registra_usuario;
        private Label label1;
        private PictureBox pictureBox4;
        private TextBox Con_contraseña;
        private PictureBox pictureBox1;
        private LinkLabel ir_inicio;
        private Label label2;
        private Label label3;
        private Label label5;
        private Label label4;
    }
}