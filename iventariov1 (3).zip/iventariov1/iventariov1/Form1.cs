namespace iventariov1
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }
        public static class DatosUsuario
        {
            public static string NombreUsuario { get; set; } = string.Empty; // Cadena vac�a como valor inicial
        }
        private void button1_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void button2_Click(object sender, EventArgs e)
        {
            // Este es el bot�n de iniciar sesi�n
            string nombreUsuario = usuario.Text; // Nombre de usuario
            string contrasena = contrase�a.Text;    // Contrase�a

            // Validar que los campos no est�n vac�os
            if (string.IsNullOrWhiteSpace(nombreUsuario) || string.IsNullOrWhiteSpace(contrasena))
            {
                MessageBox.Show("Por favor, complete ambos campos.", "Advertencia", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            // Verificar las credenciales
            if (nombreUsuario == "admin" && contrasena == "123")
            {
                MessageBox.Show("Inicio de sesi�n exitoso.", "�xito", MessageBoxButtons.OK, MessageBoxIcon.Information);
                adminforms iniciarform = new adminforms();
                iniciarform.Show();
                this.Hide();
            }
            else if (VerificarCredenciales(nombreUsuario, contrasena))
            {
                MessageBox.Show("Inicio de sesi�n exitoso.", "�xito", MessageBoxButtons.OK, MessageBoxIcon.Information);
                Form3 iniciarform = new Form3();
                iniciarform.Show();
                this.Hide();

            }
            else
            {
                MessageBox.Show("Nombre de usuario o contrase�a incorrectos.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void textBox2_TextChanged(object sender, EventArgs e)
        {

        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {
            DatosUsuario.NombreUsuario = usuario.Text;
        }

        private void label2_Click(object sender, EventArgs e)
        {

        }

        private void pictureBox1_Click(object sender, EventArgs e)
        {

        }

        private void pictureBox3_Click(object sender, EventArgs e)
        {

        }

        private void label3_Click(object sender, EventArgs e)
        {

        }

        private void label4_Click(object sender, EventArgs e)
        {

        }

        private void linkLabel1_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {
            // Navegar a la pantalla de registro (Form1)
            Form3 iniciarform = new Form3();
            iniciarform.Show();
            this.Hide();
        }
        private bool VerificarCredenciales(string usuario, string contrasena)
        {
            string filePath = "usuarios.txt";

            if (!File.Exists(filePath))
            {
                MessageBox.Show("No hay usuarios registrados.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return false;
            }

            using (StreamReader sr = new StreamReader(filePath))
            {
                string? linea;  // Usamos string? para indicar que la variable puede ser nula
                string usuarioGuardado = "";
                string contrasenaGuardada = "";

                // Este bucle leer� cada l�nea mientras no sea null
                while ((linea = sr.ReadLine()) != null)
                {
                    if (string.IsNullOrWhiteSpace(linea)) // Saltar l�neas vac�as o que contengan solo espacios en blanco
                        continue;

                    if (linea.StartsWith("Usuario: "))
                    {
                        usuarioGuardado = linea.Replace("Usuario: ", "").Trim();
                    }
                    else if (linea.StartsWith("Contrase�a: "))
                    {
                        contrasenaGuardada = linea.Replace("Contrase�a: ", "").Trim();

                        // Si el usuario y la contrase�a coinciden, devolver true
                        if (usuarioGuardado == usuario && contrasenaGuardada == contrasena)
                        {
                            return true;
                        }
                    }
                }
            }

            return false; // Si no se encontr� ninguna coincidencia
        }

        private void linkLabel1_LinkClicked_1(object sender, LinkLabelLinkClickedEventArgs e)
        {
            Form2 iniciarform = new Form2();
            iniciarform.Show();
            this.Hide();
        }
    }
}