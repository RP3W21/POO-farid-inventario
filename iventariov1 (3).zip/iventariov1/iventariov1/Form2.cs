﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace iventariov1
{

    public partial class Form2 : Form
    {
        public Form2()
        {
            InitializeComponent();
        }
        private bool UsuarioExiste(string usuario)
        {
            string filePath = "usuarios.txt";

            if (!File.Exists(filePath))
            {
                return false; // El archivo no existe, por lo tanto, el usuario no puede existir
            }

            using (StreamReader sr = new StreamReader(filePath))
            {
                string? line; // Usamos string? para permitir valores nulos
                while ((line = sr.ReadLine()) != null)
                {
                    if (string.IsNullOrWhiteSpace(line)) // Saltar líneas vacías
                        continue;

                    if (line.StartsWith("Usuario: " + usuario))
                    {
                        return true; // El usuario ya existe en el archivo
                    }
                }
            }

            return false; // El usuario no fue encontrado en el archivo
        }


        private void Form2_Load(object sender, EventArgs e)
        {

        }

        private void panel1_Paint(object sender, PaintEventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            // Botón para salir de la aplicación
            Application.Exit();
        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {
            // textBox1 es para el nombre de usuario
        }

        private void textBox2_TextChanged(object sender, EventArgs e)
        {
            // textBox2 es para la contraseña
        }

        private void textBox3_TextChanged(object sender, EventArgs e)
        {
            // textBox3 es para confirmar la contraseña
        }

        private void button2_Click(object sender, EventArgs e)
        {
            string nombreUsuario = Registra_usuario.Text;
            string contrasena = Registrar_contraseña.Text;
            string confirmarContrasena = Con_contraseña.Text;

            // Validación para campos vacíos
            if (string.IsNullOrWhiteSpace(nombreUsuario) || string.IsNullOrWhiteSpace(contrasena) || string.IsNullOrWhiteSpace(confirmarContrasena))
            {
                MessageBox.Show("Por favor, complete todos los campos.", "Advertencia", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            // Validación de longitud mínima de 5 caracteres
            if (nombreUsuario.Length < 5)
            {
                MessageBox.Show("El nombre de usuario debe tener al menos 5 caracteres.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }

            if (contrasena.Length < 5)
            {
                MessageBox.Show("La contraseña debe tener al menos 5 caracteres.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }

            // Validar que las contraseñas coincidan
            if (contrasena != confirmarContrasena)
            {
                MessageBox.Show("Las contraseñas no coinciden.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }

            // Verificar si el usuario ya existe
            if (UsuarioExiste(nombreUsuario))
            {
                MessageBox.Show("El nombre de usuario ya existe. Por favor, elija otro nombre.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }

            // Guardar los datos en un archivo .txt
            GuardarUsuarioYContrasena(nombreUsuario, contrasena);

            // Limpiar los campos después del registro
            LimpiarCampos();

            MessageBox.Show("Registro completado correctamente.", "Éxito", MessageBoxButtons.OK, MessageBoxIcon.Information);
        }

        private void GuardarUsuarioYContrasena(string usuario, string contrasena)
        {
            string filePath = "usuarios.txt";

            try
            {
                using (StreamWriter sw = File.AppendText(filePath))
                {
                    sw.WriteLine("Usuario: " + usuario);
                    sw.WriteLine("Contraseña: " + contrasena);
                    sw.WriteLine("------------------------");
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Ocurrió un error al guardar los datos: " + ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void LimpiarCampos()
        {
            Registra_usuario.Clear(); // Limpiar nombre de usuario
            Registrar_contraseña.Clear(); // Limpiar contraseña
            Con_contraseña.Clear(); // Limpiar confirmación de contraseña
        }

        private void ir_inicio_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {
            // Navegar a la pantalla de inicio (Form1)
            Form1 iniciarform = new Form1();
            iniciarform.Show();
            this.Hide();
        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void label2_Click(object sender, EventArgs e)
        {

        }

        private void label3_Click(object sender, EventArgs e)
        {

        }

        private void pictureBox3_Click(object sender, EventArgs e)
        {

        }

        private void pictureBox2_Click(object sender, EventArgs e)
        {

        }

        private void label1_Click_1(object sender, EventArgs e)
        {

        }

        private void ir_inicio_LinkClicked_1(object sender, LinkLabelLinkClickedEventArgs e)
        {
            Form1 iniciarform = new Form1();
            iniciarform.Show();
            this.Hide();
        }
    }
}
