﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using static iventariov1.Form1;

namespace iventariov1
{
    public partial class adminforms : Form
    {
        public adminforms()
        {
            InitializeComponent();
            FormUsuarios_Load(null, null);
        }

        private void loadnombre_Click(object sender, EventArgs e)
        {
            loadnombre.Text = "Bienvenido, " + DatosUsuario.NombreUsuario + "!";
        }

        private void linkLabel1_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {
            Form1 iniciarform = new Form1();
            iniciarform.Show();
            this.Hide();
        }

        private void pictureBox2_Click(object sender, EventArgs e)
        {

        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void label2_Click(object sender, EventArgs e)
        {

        }

        private void label4_Click(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {

        }

        private void button3_Click(object sender, EventArgs e)
        {

        }

        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }
        private void FormUsuarios_Load(object sender, EventArgs e)
        {
            // Ruta al archivo de usuarios
            string filePath = "usuarios.txt";

            // Verificar si el archivo existe
            if (File.Exists(filePath))
            {
                // Leer todas las líneas del archivo
                string[] lineas = File.ReadAllLines(filePath);

                // Recorrer las líneas del archivo
                foreach (string linea in lineas)
                {
                    // Buscar la línea que comienza con "Usuario: "
                    if (linea.StartsWith("Usuario: "))
                    {
                        // Extraer el nombre de usuario y agregarlo al ListBox
                        string nombreUsuario = linea.Substring(9); // Eliminar "Usuario: " para obtener solo el nombre
                        listBox1.Items.Add(nombreUsuario); // Agregar el nombre al listBox1
                    }
                }
            }
            else
            {
                // Mostrar un mensaje si el archivo no se encuentra
                MessageBox.Show("El archivo de usuarios no fue encontrado.");
            }
        }
        private void listBox1_SelectedIndexChanged(object sender, EventArgs e)
        {

        }
    }
}
