﻿namespace iventariov1
{
    partial class Form3
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Form3));
            panel1 = new Panel();
            loadnombre = new Label();
            linkLabel1 = new LinkLabel();
            pictureBox1 = new PictureBox();
            label3 = new Label();
            panel2 = new Panel();
            panel3 = new Panel();
            panel4 = new Panel();
            label2 = new Label();
            panel5 = new Panel();
            label1 = new Label();
            panel6 = new Panel();
            label4 = new Label();
            label5 = new Label();
            button2 = new Button();
            button1 = new Button();
            panel1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)pictureBox1).BeginInit();
            panel2.SuspendLayout();
            panel3.SuspendLayout();
            panel4.SuspendLayout();
            panel5.SuspendLayout();
            panel6.SuspendLayout();
            SuspendLayout();
            // 
            // panel1
            // 
            panel1.BackColor = Color.White;
            panel1.Controls.Add(loadnombre);
            panel1.Controls.Add(linkLabel1);
            panel1.Controls.Add(pictureBox1);
            panel1.Controls.Add(label3);
            panel1.Location = new Point(12, 15);
            panel1.Name = "panel1";
            panel1.Size = new Size(200, 423);
            panel1.TabIndex = 0;
            // 
            // loadnombre
            // 
            loadnombre.AutoSize = true;
            loadnombre.Font = new Font("MS PGothic", 14.25F, FontStyle.Regular, GraphicsUnit.Point);
            loadnombre.ForeColor = Color.Black;
            loadnombre.Location = new Point(96, 152);
            loadnombre.Name = "loadnombre";
            loadnombre.Size = new Size(101, 19);
            loadnombre.TabIndex = 18;
            loadnombre.Text = "loadnombre";
            loadnombre.Click += label1_Click;
            // 
            // linkLabel1
            // 
            linkLabel1.AutoSize = true;
            linkLabel1.Font = new Font("MS PGothic", 11.25F, FontStyle.Regular, GraphicsUnit.Point);
            linkLabel1.LinkColor = Color.Blue;
            linkLabel1.Location = new Point(53, 397);
            linkLabel1.Name = "linkLabel1";
            linkLabel1.Size = new Size(91, 15);
            linkLabel1.TabIndex = 17;
            linkLabel1.TabStop = true;
            linkLabel1.Text = "cerrar sesion";
            linkLabel1.LinkClicked += linkLabel1_LinkClicked;
            // 
            // pictureBox1
            // 
            pictureBox1.Image = (Image)resources.GetObject("pictureBox1.Image");
            pictureBox1.Location = new Point(33, 3);
            pictureBox1.Name = "pictureBox1";
            pictureBox1.Size = new Size(135, 127);
            pictureBox1.SizeMode = PictureBoxSizeMode.StretchImage;
            pictureBox1.TabIndex = 16;
            pictureBox1.TabStop = false;
            // 
            // label3
            // 
            label3.AutoSize = true;
            label3.Font = new Font("MS PGothic", 14.25F, FontStyle.Regular, GraphicsUnit.Point);
            label3.ForeColor = Color.Black;
            label3.Location = new Point(3, 152);
            label3.Name = "label3";
            label3.Size = new Size(97, 19);
            label3.TabIndex = 15;
            label3.Text = "Bienvenido";
            label3.Click += label3_Click;
            // 
            // panel2
            // 
            panel2.BackColor = Color.White;
            panel2.Controls.Add(button1);
            panel2.Controls.Add(label4);
            panel2.Location = new Point(216, 133);
            panel2.Name = "panel2";
            panel2.Size = new Size(276, 305);
            panel2.TabIndex = 1;
            // 
            // panel3
            // 
            panel3.BackColor = Color.White;
            panel3.Controls.Add(panel5);
            panel3.Controls.Add(panel4);
            panel3.Location = new Point(215, 15);
            panel3.Name = "panel3";
            panel3.Size = new Size(573, 112);
            panel3.TabIndex = 2;
            // 
            // panel4
            // 
            panel4.BackColor = Color.FromArgb(128, 128, 255);
            panel4.Controls.Add(label2);
            panel4.Location = new Point(3, 3);
            panel4.Name = "panel4";
            panel4.Size = new Size(258, 106);
            panel4.TabIndex = 1;
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.Font = new Font("MS PGothic", 9.75F, FontStyle.Regular, GraphicsUnit.Point);
            label2.ForeColor = Color.Transparent;
            label2.Location = new Point(3, 10);
            label2.Name = "label2";
            label2.Size = new Size(106, 13);
            label2.TabIndex = 20;
            label2.Text = "Dinero en Carrito";
            // 
            // panel5
            // 
            panel5.BackColor = Color.FromArgb(128, 128, 255);
            panel5.Controls.Add(label1);
            panel5.Location = new Point(312, 3);
            panel5.Name = "panel5";
            panel5.Size = new Size(258, 106);
            panel5.TabIndex = 21;
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Font = new Font("MS PGothic", 9.75F, FontStyle.Regular, GraphicsUnit.Point);
            label1.ForeColor = Color.Transparent;
            label1.Location = new Point(3, 10);
            label1.Name = "label1";
            label1.Size = new Size(70, 13);
            label1.TabIndex = 20;
            label1.Text = "Gasto total";
            // 
            // panel6
            // 
            panel6.BackColor = Color.White;
            panel6.Controls.Add(button2);
            panel6.Controls.Add(label5);
            panel6.Location = new Point(498, 133);
            panel6.Name = "panel6";
            panel6.Size = new Size(290, 305);
            panel6.TabIndex = 2;
            // 
            // label4
            // 
            label4.AutoSize = true;
            label4.Font = new Font("MS PGothic", 14.25F, FontStyle.Regular, GraphicsUnit.Point);
            label4.ForeColor = Color.Black;
            label4.Location = new Point(5, 9);
            label4.Name = "label4";
            label4.Size = new Size(66, 19);
            label4.TabIndex = 19;
            label4.Text = "Carrito";
            label4.Click += label4_Click;
            // 
            // label5
            // 
            label5.AutoSize = true;
            label5.Font = new Font("MS PGothic", 14.25F, FontStyle.Regular, GraphicsUnit.Point);
            label5.ForeColor = Color.Black;
            label5.Location = new Point(3, 9);
            label5.Name = "label5";
            label5.Size = new Size(93, 19);
            label5.TabIndex = 20;
            label5.Text = "Productos";
            // 
            // button2
            // 
            button2.BackColor = Color.FromArgb(67, 90, 217);
            button2.FlatStyle = FlatStyle.Flat;
            button2.Font = new Font("MS PGothic", 9.75F, FontStyle.Bold, GraphicsUnit.Point);
            button2.ForeColor = SystemColors.ButtonFace;
            button2.Location = new Point(3, 265);
            button2.Name = "button2";
            button2.Size = new Size(151, 37);
            button2.TabIndex = 21;
            button2.Text = "agregar a carrito";
            button2.UseVisualStyleBackColor = false;
            // 
            // button1
            // 
            button1.BackColor = Color.FromArgb(67, 90, 217);
            button1.FlatStyle = FlatStyle.Flat;
            button1.Font = new Font("MS PGothic", 9.75F, FontStyle.Bold, GraphicsUnit.Point);
            button1.ForeColor = SystemColors.ButtonFace;
            button1.Location = new Point(5, 265);
            button1.Name = "button1";
            button1.Size = new Size(118, 38);
            button1.TabIndex = 20;
            button1.Text = "Hacer compra";
            button1.UseVisualStyleBackColor = false;
            button1.Click += button1_Click;
            // 
            // Form3
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            BackColor = Color.FromArgb(67, 90, 217);
            ClientSize = new Size(800, 450);
            Controls.Add(panel6);
            Controls.Add(panel3);
            Controls.Add(panel2);
            Controls.Add(panel1);
            Name = "Form3";
            Text = "Form3";
            panel1.ResumeLayout(false);
            panel1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)pictureBox1).EndInit();
            panel2.ResumeLayout(false);
            panel2.PerformLayout();
            panel3.ResumeLayout(false);
            panel4.ResumeLayout(false);
            panel4.PerformLayout();
            panel5.ResumeLayout(false);
            panel5.PerformLayout();
            panel6.ResumeLayout(false);
            panel6.PerformLayout();
            ResumeLayout(false);
        }

        #endregion

        private Panel panel1;
        private Label label3;
        private PictureBox pictureBox1;
        private LinkLabel linkLabel1;
        private Label loadnombre;
        private Panel panel2;
        private Panel panel3;
        private Panel panel5;
        private Label label1;
        private Panel panel4;
        private Label label2;
        private Panel panel6;
        private Label label4;
        private Label label5;
        private Button button1;
        private Button button2;
    }
}