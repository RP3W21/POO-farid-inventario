﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.IO;
using static iventariov1.Form1;

namespace iventariov1
{
    public partial class Form3 : Form
    {
        public Form3()
        {
            InitializeComponent();
            loadnombre.Text = DatosUsuario.NombreUsuario;
        }

        private void label3_Click(object sender, EventArgs e)
        {

        }

        private void linkLabel1_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {
            Form1 iniciarform = new Form1();
            iniciarform.Show();
            this.Hide();
        }

        private void label1_Click(object sender, EventArgs e)
        {
            loadnombre.Text = "Bienvenido, " + DatosUsuario.NombreUsuario + "!";
        }

        private void checkedListBox1_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        private void pictureBox2_Click(object sender, EventArgs e)
        {

        }

        private void label4_Click(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {

        }
    }
}
