﻿namespace iventariov1
{
    partial class adminforms
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(adminforms));
            panel3 = new Panel();
            panel7 = new Panel();
            label6 = new Label();
            panel6 = new Panel();
            label5 = new Label();
            panel5 = new Panel();
            label4 = new Label();
            panel4 = new Panel();
            label2 = new Label();
            panel2 = new Panel();
            label1 = new Label();
            panel1 = new Panel();
            loadnombre = new Label();
            linkLabel1 = new LinkLabel();
            pictureBox1 = new PictureBox();
            label3 = new Label();
            button1 = new Button();
            button2 = new Button();
            panel3.SuspendLayout();
            panel7.SuspendLayout();
            panel6.SuspendLayout();
            panel5.SuspendLayout();
            panel4.SuspendLayout();
            panel2.SuspendLayout();
            panel1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)pictureBox1).BeginInit();
            SuspendLayout();
            // 
            // panel3
            // 
            panel3.BackColor = Color.White;
            panel3.Controls.Add(panel7);
            panel3.Controls.Add(panel6);
            panel3.Controls.Add(panel5);
            panel3.Controls.Add(panel4);
            panel3.Location = new Point(215, 14);
            panel3.Name = "panel3";
            panel3.Size = new Size(573, 112);
            panel3.TabIndex = 5;
            // 
            // panel7
            // 
            panel7.BackColor = Color.FromArgb(128, 128, 255);
            panel7.Controls.Add(label6);
            panel7.Location = new Point(451, 3);
            panel7.Name = "panel7";
            panel7.Size = new Size(119, 106);
            panel7.TabIndex = 1;
            // 
            // label6
            // 
            label6.AutoSize = true;
            label6.Font = new Font("MS PGothic", 9.75F, FontStyle.Regular, GraphicsUnit.Point);
            label6.ForeColor = Color.Transparent;
            label6.Location = new Point(14, 12);
            label6.Name = "label6";
            label6.Size = new Size(102, 13);
            label6.TabIndex = 23;
            label6.Text = "posibles ingresos";
            // 
            // panel6
            // 
            panel6.BackColor = Color.FromArgb(128, 128, 255);
            panel6.Controls.Add(label5);
            panel6.Location = new Point(301, 3);
            panel6.Name = "panel6";
            panel6.Size = new Size(119, 106);
            panel6.TabIndex = 1;
            // 
            // label5
            // 
            label5.AutoSize = true;
            label5.Font = new Font("MS PGothic", 9.75F, FontStyle.Regular, GraphicsUnit.Point);
            label5.ForeColor = Color.Transparent;
            label5.Location = new Point(11, 12);
            label5.Name = "label5";
            label5.Size = new Size(105, 13);
            label5.TabIndex = 22;
            label5.Text = "ingresos actuales";
            // 
            // panel5
            // 
            panel5.BackColor = Color.FromArgb(128, 128, 255);
            panel5.Controls.Add(label4);
            panel5.Location = new Point(152, 3);
            panel5.Name = "panel5";
            panel5.Size = new Size(119, 106);
            panel5.TabIndex = 1;
            // 
            // label4
            // 
            label4.AutoSize = true;
            label4.Font = new Font("MS PGothic", 9.75F, FontStyle.Regular, GraphicsUnit.Point);
            label4.ForeColor = Color.Transparent;
            label4.Location = new Point(3, 12);
            label4.Name = "label4";
            label4.Size = new Size(116, 13);
            label4.TabIndex = 21;
            label4.Text = "productos en venta";
            label4.Click += label4_Click;
            // 
            // panel4
            // 
            panel4.BackColor = Color.FromArgb(128, 128, 255);
            panel4.Controls.Add(label2);
            panel4.Location = new Point(3, 3);
            panel4.Name = "panel4";
            panel4.Size = new Size(119, 106);
            panel4.TabIndex = 0;
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.Font = new Font("MS PGothic", 9.75F, FontStyle.Regular, GraphicsUnit.Point);
            label2.ForeColor = Color.Transparent;
            label2.Location = new Point(0, 12);
            label2.Name = "label2";
            label2.Size = new Size(120, 13);
            label2.TabIndex = 20;
            label2.Text = "Numero de Usuarios";
            label2.Click += label2_Click;
            // 
            // panel2
            // 
            panel2.BackColor = Color.White;
            panel2.Controls.Add(label1);
            panel2.Location = new Point(215, 132);
            panel2.Name = "panel2";
            panel2.Size = new Size(573, 305);
            panel2.TabIndex = 4;
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Font = new Font("MS PGothic", 14.25F, FontStyle.Regular, GraphicsUnit.Point);
            label1.ForeColor = Color.Black;
            label1.Location = new Point(3, 10);
            label1.Name = "label1";
            label1.Size = new Size(79, 19);
            label1.TabIndex = 19;
            label1.Text = "Usuarios";
            label1.Click += label1_Click;
            // 
            // panel1
            // 
            panel1.BackColor = Color.White;
            panel1.Controls.Add(button2);
            panel1.Controls.Add(button1);
            panel1.Controls.Add(loadnombre);
            panel1.Controls.Add(linkLabel1);
            panel1.Controls.Add(pictureBox1);
            panel1.Controls.Add(label3);
            panel1.Location = new Point(12, 14);
            panel1.Name = "panel1";
            panel1.Size = new Size(200, 423);
            panel1.TabIndex = 3;
            // 
            // loadnombre
            // 
            loadnombre.AutoSize = true;
            loadnombre.Font = new Font("MS PGothic", 14.25F, FontStyle.Regular, GraphicsUnit.Point);
            loadnombre.ForeColor = Color.Black;
            loadnombre.Location = new Point(96, 152);
            loadnombre.Name = "loadnombre";
            loadnombre.Size = new Size(101, 19);
            loadnombre.TabIndex = 18;
            loadnombre.Text = "loadnombre";
            loadnombre.Click += loadnombre_Click;
            // 
            // linkLabel1
            // 
            linkLabel1.AutoSize = true;
            linkLabel1.Font = new Font("MS PGothic", 11.25F, FontStyle.Regular, GraphicsUnit.Point);
            linkLabel1.LinkColor = Color.Blue;
            linkLabel1.Location = new Point(53, 397);
            linkLabel1.Name = "linkLabel1";
            linkLabel1.Size = new Size(91, 15);
            linkLabel1.TabIndex = 17;
            linkLabel1.TabStop = true;
            linkLabel1.Text = "cerrar sesion";
            linkLabel1.LinkClicked += linkLabel1_LinkClicked;
            // 
            // pictureBox1
            // 
            pictureBox1.Image = (Image)resources.GetObject("pictureBox1.Image");
            pictureBox1.Location = new Point(33, 3);
            pictureBox1.Name = "pictureBox1";
            pictureBox1.Size = new Size(135, 127);
            pictureBox1.SizeMode = PictureBoxSizeMode.StretchImage;
            pictureBox1.TabIndex = 16;
            pictureBox1.TabStop = false;
            // 
            // label3
            // 
            label3.AutoSize = true;
            label3.Font = new Font("MS PGothic", 14.25F, FontStyle.Regular, GraphicsUnit.Point);
            label3.ForeColor = Color.Black;
            label3.Location = new Point(3, 152);
            label3.Name = "label3";
            label3.Size = new Size(97, 19);
            label3.TabIndex = 15;
            label3.Text = "Bienvenido";
            // 
            // button1
            // 
            button1.BackColor = Color.FromArgb(67, 90, 217);
            button1.FlatStyle = FlatStyle.Flat;
            button1.Font = new Font("MS PGothic", 9.75F, FontStyle.Bold, GraphicsUnit.Point);
            button1.ForeColor = SystemColors.ButtonFace;
            button1.Location = new Point(4, 243);
            button1.Name = "button1";
            button1.Size = new Size(193, 38);
            button1.TabIndex = 21;
            button1.Text = "Administrar productos";
            button1.UseVisualStyleBackColor = false;
            button1.Click += button1_Click;
            // 
            // button2
            // 
            button2.BackColor = Color.FromArgb(67, 90, 217);
            button2.FlatStyle = FlatStyle.Flat;
            button2.Font = new Font("MS PGothic", 9.75F, FontStyle.Bold, GraphicsUnit.Point);
            button2.ForeColor = SystemColors.ButtonFace;
            button2.Location = new Point(4, 199);
            button2.Name = "button2";
            button2.Size = new Size(193, 38);
            button2.TabIndex = 22;
            button2.Text = "Administrar usuarios";
            button2.UseVisualStyleBackColor = false;
            // 
            // adminforms
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            BackColor = Color.FromArgb(67, 90, 217);
            ClientSize = new Size(800, 450);
            Controls.Add(panel3);
            Controls.Add(panel2);
            Controls.Add(panel1);
            Name = "adminforms";
            Text = "adminforms";
            panel3.ResumeLayout(false);
            panel7.ResumeLayout(false);
            panel7.PerformLayout();
            panel6.ResumeLayout(false);
            panel6.PerformLayout();
            panel5.ResumeLayout(false);
            panel5.PerformLayout();
            panel4.ResumeLayout(false);
            panel4.PerformLayout();
            panel2.ResumeLayout(false);
            panel2.PerformLayout();
            panel1.ResumeLayout(false);
            panel1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)pictureBox1).EndInit();
            ResumeLayout(false);
        }

        #endregion

        private Panel panel3;
        private Panel panel2;
        private Panel panel1;
        private Label loadnombre;
        private LinkLabel linkLabel1;
        private PictureBox pictureBox1;
        private Label label3;
        private Panel panel7;
        private Panel panel6;
        private Panel panel5;
        private Panel panel4;
        private Label label1;
        private Label label2;
        private Label label6;
        private Label label5;
        private Label label4;
        private Button button2;
        private Button button1;
    }
}